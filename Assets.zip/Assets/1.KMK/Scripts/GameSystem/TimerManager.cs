using System;
using UnityEngine;

public class TimerManager : MonoBehaviour
{
    public float currentTime;
    private bool isTimerRunning = false;

    public void StartTimer(float time)
    {
        currentTime = time;
        isTimerRunning = true;
    }

    public void ResetTimer(float time)
    {
        currentTime = time;
    }

    public void AddTime(float extraTime)
    {
        currentTime += extraTime;
        Debug.Log($"�ð� ����. ���� �ð�: {currentTime}��");
    }

    public void StopTimer()
    {
        isTimerRunning = false;
    }

    public void TickTimer(float deltaTime)
    {
        if (!isTimerRunning) return;

        currentTime -= deltaTime; // �� �����Ӹ��� �ð� ���
        if (currentTime <= 0)
        {
            currentTime = 0;
            isTimerRunning = false;
        }
    }
    // ���� �� �� ���Ҵ��� �˷��ִ� �Լ�
    public float GetCurrentTime()
    {
        return currentTime;
    }
    public bool IsTimeUp()
    {
        return !isTimerRunning && currentTime <= 0;
    }
}

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class BoardDebugController : MonoBehaviour
{
    [SerializeField] private PlayerPawn playerPawn;
    [SerializeField] private int selectedBranchIndex = 0;

    private void Start()
    {
        Debug.Log("=== Board Debug Controller ===");
        Debug.Log("1 / 3 / 5 : �̵�");
        Debug.Log("Q / W / E : ���� �б� ���� (0 / 1 / 2)");
        Debug.Log("B : ���õ� ���� ��忡 BananaPeel ��ġ");
        Debug.Log("F : ���õ� ���� ��忡 FakeTrophy ��ġ");
        Debug.Log("C : ���õ� ���� ��� ���� ����");
        Debug.Log("I : ���� ��� ���� ���");
    }

    private void Update()
    {
        if (Keyboard.current == null || playerPawn == null || playerPawn.IsMoving)
            return;

        if (Keyboard.current.qKey.wasPressedThisFrame)
        {
            selectedBranchIndex = 0;
            Debug.Log("[Debug] ���� �б� ���� = 0");
        }

        if (Keyboard.current.wKey.wasPressedThisFrame)
        {
            selectedBranchIndex = 1;
            Debug.Log("[Debug] ���� �б� ���� = 1");
        }

        if (Keyboard.current.eKey.wasPressedThisFrame)
        {
            selectedBranchIndex = 2;
            Debug.Log("[Debug] ���� �б� ���� = 2");
        }

        if (Keyboard.current.digit1Key.wasPressedThisFrame)
        {
            playerPawn.MoveSteps(1, new List<int> { selectedBranchIndex });
        }

        if (Keyboard.current.digit3Key.wasPressedThisFrame)
        {
            playerPawn.MoveSteps(3, new List<int> { selectedBranchIndex });
        }

        if (Keyboard.current.digit5Key.wasPressedThisFrame)
        {
            playerPawn.MoveSteps(5, new List<int> { selectedBranchIndex });
        }

        if (Keyboard.current.bKey.wasPressedThisFrame)
        {
            BoardNode targetNode = GetSelectedNextNode();
            if (targetNode != null)
                targetNode.InstallTrap(TrapType.BananaPeel, playerPawn.PawnName);
        }

        if (Keyboard.current.fKey.wasPressedThisFrame)
        {
            BoardNode targetNode = GetSelectedNextNode();
            if (targetNode != null)
                targetNode.InstallTrap(TrapType.FakeTrophy, playerPawn.PawnName);
        }

        if (Keyboard.current.cKey.wasPressedThisFrame)
        {
            BoardNode targetNode = GetSelectedNextNode();
            if (targetNode != null)
                targetNode.ClearTrap();
        }

        if (Keyboard.current.iKey.wasPressedThisFrame)
        {
            PrintCurrentNodeInfo();
        }
    }

    private BoardNode GetSelectedNextNode()
    {
        BoardNode currentNode = playerPawn.CurrentNode;
        if (currentNode == null || currentNode.NextNodes == null || currentNode.NextNodes.Count == 0)
        {
            Debug.LogWarning("[Debug] ���� ��忡 ����� ���� ��尡 �����ϴ�.");
            return null;
        }

        int clampedIndex = Mathf.Clamp(selectedBranchIndex, 0, currentNode.NextNodes.Count - 1);
        return currentNode.NextNodes[clampedIndex];
    }

    private void PrintCurrentNodeInfo()
    {
        BoardNode currentNode = playerPawn.CurrentNode;
        if (currentNode == null)
        {
            Debug.LogWarning("[Debug] CurrentNode�� �����ϴ�.");
            return;
        }

        Debug.Log($"[Debug] ���� ��� = {currentNode.NodeId}, Type = {currentNode.NodeType}, NextCount = {currentNode.NextNodes.Count}");
    }
}
using UnityEngine;
using UnityEngine.InputSystem;

public class DeckDebugController : MonoBehaviour
{
    [SerializeField] private DeckController deckController;
    [SerializeField] private CharacterInfo characterInfo;

    private void Start()
    {
        Debug.Log("=== Deck Debug Controller ===");
        Debug.Log("R : ī�� 1�� ��ο�");
        Debug.Log("T : ī�� 3�� ��ο�");
        Debug.Log("H : ���� ���");
        Debug.Log("U / I / O : ���� 0 / 1 / 2 ���");
        Debug.Log("M : ���� ��ü ȸ��");
    }

    private void Update()
    {
        if (Keyboard.current == null || deckController == null)
            return;

        if (Keyboard.current.rKey.wasPressedThisFrame)
        {
            deckController.DrawCard();
        }

        if (Keyboard.current.tKey.wasPressedThisFrame)
        {
            deckController.DrawMany(3);
        }

        if (Keyboard.current.hKey.wasPressedThisFrame)
        {
            deckController.PrintHand();
        }

        if (Keyboard.current.uKey.wasPressedThisFrame)
        {
            deckController.UseCard(0);
        }

        if (Keyboard.current.iKey.wasPressedThisFrame)
        {
            deckController.UseCard(1);
        }

        if (Keyboard.current.oKey.wasPressedThisFrame)
        {
            deckController.UseCard(2);
        }

        if (Keyboard.current.mKey.wasPressedThisFrame)
        {
            if (characterInfo != null)
                characterInfo.RestoreManaToFull();
        }
    }
}
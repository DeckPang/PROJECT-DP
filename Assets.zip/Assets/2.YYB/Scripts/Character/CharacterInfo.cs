using UnityEngine;

public class CharacterInfo : MonoBehaviour
{
    [Header("Identity")]
    [SerializeField] private string playerId = "P1";
    [SerializeField] private string userName = "Player1";

    [Header("Stats")]
    [SerializeField] private int hp = 5;
    [SerializeField] private int coins = 0;
    [SerializeField] private int trophies = 0;

    [Header("Mana")]
    [SerializeField] private int maxMana = 5;
    [SerializeField] private int currentMana = 5;

    public string PlayerId => playerId;
    public string UserName => userName;
    public int Hp => hp;
    public int Coins => coins;
    public int Trophies => trophies;
    public int MaxMana => maxMana;
    public int CurrentMana => currentMana;

    private void Awake()
    {
        currentMana = Mathf.Clamp(currentMana, 0, maxMana);
        if (currentMana == 0)
            currentMana = maxMana;
    }

    public void SetUserName(string newName)
    {
        userName = newName;
        Debug.Log($"[CharacterInfo] �̸� ����: {userName}");
    }

    public void ChangeHp(int amount)
    {
        hp += amount;
        hp = Mathf.Max(0, hp);
        Debug.Log($"[CharacterInfo] HP ��ȭ: {amount} | ���� HP: {hp}");
    }

    public void ChangeCoins(int amount)
    {
        coins += amount;
        coins = Mathf.Max(0, coins);
        Debug.Log($"[CharacterInfo] Coin ��ȭ: {amount} | ���� Coin: {coins}");
    }

    public void AddTrophy(int amount = 1)
    {
        trophies += amount;
        trophies = Mathf.Max(0, trophies);
        Debug.Log($"[CharacterInfo] Trophy ��ȭ: +{amount} | ���� Trophy: {trophies}");
    }

    public void IncreaseMaxMana(int amount)
    {
        maxMana += amount;
        maxMana = Mathf.Max(0, maxMana);
        currentMana = Mathf.Clamp(currentMana, 0, maxMana);
        Debug.Log($"[CharacterInfo] MaxMana ����: +{amount} | ���� MaxMana: {maxMana}");
    }

    public void RestoreManaToFull()
    {
        currentMana = maxMana;
        Debug.Log($"[CharacterInfo] ���� ���� ȸ�� | ���� Mana: {currentMana}/{maxMana}");
    }

    public void ChangeMana(int amount)
    {
        currentMana += amount;
        currentMana = Mathf.Clamp(currentMana, 0, maxMana);
        Debug.Log($"[CharacterInfo] Mana ��ȭ: {amount} | ���� Mana: {currentMana}/{maxMana}");
    }

    public bool TrySpendMana(int cost)
    {
        if (currentMana < cost)
        {
            Debug.LogWarning($"[CharacterInfo] ���� ���� | �ʿ�: {cost}, ����: {currentMana}");
            return false;
        }

        currentMana -= cost;
        Debug.Log($"[CharacterInfo] ���� ���: -{cost} | ���� Mana: {currentMana}/{maxMana}");
        return true;
    }
}